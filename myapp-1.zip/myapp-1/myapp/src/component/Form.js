import { useState } from 'react';

const Form = () => {
  // const fnameRef = React.useRef();
  // const lnameRef = React.useRef();

  // const usernameRef = React.useRef();
  // const passwordRef = React.useRef();

  const [error, setError] = useState(null);

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const changeHandler = (e) => {
    // console.log(e.target.value);
    const isLowerCase = e.target.value === e.target.value.toLowerCase();
    setError(isLowerCase ? null : 'Username should be all small');
  };

  const submitHandler = (e) => {
    e.preventDefault();
  };

  // const submitHandler = (e) => {
  //   e.preventDefault();
  //   // console.dir(e.target[0].value);
  //   // console.dir(e.target[1].value);
  //   // console.dir(e.target.elements.fname.value);
  //   // console.dir(e.target.elements.lname.value);

  //   // const { fname, lname } = e.target.elements;
  //   // console.dir(fname.value);
  //   // console.dir(lname.value);

  //   // console.log(fnameRef);
  //   // console.log(lnameRef);
  //   // console.log(fnameRef.current.value);
  //   // console.log(lnameRef.current.value);

  //   console.log(usernameRef.current.value);
  //   console.log(passwordRef.current.value);
  // };

  return (
    <>
      <h4>My Form</h4>
      <form onSubmit={submitHandler}>
        <div>
          <label htmlFor="username">Username</label>
          <input
            id="username"
            name="username"
            value={username.toLowerCase()}
            onChange={(e) => setUsername(e.target.value)}
          />
          <br />
          <span style={{ color: 'red', fontWeight: 'bold' }}>{error}</span>
        </div>
        <div>
          <label htmlFor="password">Password</label>
          <input
            id="password"
            name="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <br />
        <button disabled={Boolean(error)} type="submit">
          Submit Information
        </button> 
      </form>
      {/* <h4>My Form</h4>
      <form onSubmit={submitHandler}>
        <div>
          <label htmlFor="fname">First Name</label>
          <input id="fname" name="fname" ref={fnameRef} />
        </div>
        <div>
          <label htmlFor="lname">Last Name</label>
          <input id="lname" name="lname" ref={lnameRef} />
        </div>
        <br />
        <button type="submit">Submit Information</button>
      </form> */}
    </>
  );
};

export default Form;
