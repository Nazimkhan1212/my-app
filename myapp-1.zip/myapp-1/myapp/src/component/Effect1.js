import { useEffect, useState } from "react";
import axios from "axios";

const Effect1 = () => {
  const [count, setCount] = useState(0);
  const [data, setData] = useState([]);

  useEffect(() => {
    const getData = async () => {
      const response = await axios.get("https://pokeapi.co/api/v2/pokemon");
      setData(response.data.results);
    };
    getData();
  },[count]);

  return (
    <div>
      <h1>Count - {count}</h1>
      <button onClick={() => setCount(count + 1)}>Increase count</button>
      {data.map((item, i) => (
        <p key={i}>{item.name}</p>
      ))}
    </div>
  );
};
export default Effect1;
