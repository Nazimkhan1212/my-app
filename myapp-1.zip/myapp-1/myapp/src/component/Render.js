import { useState } from 'react';

const Render = () => {
  const [show, setShow] = useState(false);
  const [likes, setLikes] = useState(0);
  // console.log(likes);

  const movies = [
    { id: 'mov1', value: 'The Last Samurai' },
    { id: 'mov2', value: 'Van Helsing' },
    { id: 'mov3', value: 'Braveheart' },
    { id: 'mov4', value: 'A Few Good Men' },
    { id: 'mov5', value: 'Star Wars: Episode III - Revenge of the Sith' },
  ];

  return (
    <div>
      <h1>Movies</h1>
      <div>
        <span>{likes} likes</span>
        <button onClick={() => setLikes(likes + 1)}>Like</button>
        <button onClick={() => setLikes(likes - 1)}>Dislike</button>
      </div>
      <button onClick={() => setShow(!show)}>
        {show ? 'Dikh raha hai' : 'nahi'}
      </button>
      <ul>
        {show ? movies.map((movie, i) => <li key={i}>{movie.value}</li>) : null}
      </ul>
    </div>
  );
};

export default Render;
