const Footer = () => {
  return (
    <footer>
      <p>Copyright 2022. All Right Reserved.</p>
    </footer>
  );
};

export default Footer;
