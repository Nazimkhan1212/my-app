import { useState } from "react";

const Todo1 = () => {
  const [tasks, setTasks] = useState([]);
  const [todo, setTodo] = useState("");
  const clickHandler = () => {
    // console.log(todo)
    setTasks([...tasks, todo]);
    setTodo("");
  };
  const deleteTask = (task) => setTasks(tasks.filter((t) => t !== task));
  return (
    <div>
      <input
        type="text"
        placeholder="enter your tasks"
        value={todo}
        onChange={(e) => setTodo(e.target.value)}
      />
      <button onClick={clickHandler}>Add tasks</button>
      <ul>
        {tasks.map((task, i) => (
          <li
            style={{ listStyle: "none" }}
            key={i}
            onClick={() => deleteTask(task)}
          >
            {task}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Todo1;
