import React from "react";
const Form1 = () => {
  //   const [error, setError] = React.useState(null);
  const [username, setUsername] = React.useState("");
  const [password, setPassword] = React.useState("");
  const submitHandler = (e) => {
    e.preventDefault();
    console.log(username)
    console.log(password)
  };

  //   const usernameHandler = (e)=>{

  //     const isLowerCase = e.target.value === e.target.value.toLowerCase()
  //     setError(isLowerCase?null:"Username should be all small")
  //   }

  return (
    <div>
      <h1>form</h1>
      <form onSubmit={submitHandler}>
        <label htmlFor="username">username</label>
        <br />
        <input
          type="text"
          name="username"
          value={username}
          onChange={(e) => setUsername(e.target.value.toLocaleLowerCase())}
        />
        <br />
        {/* {error?<p style={{color:"red"}}>{error}</p>:null} */}
        <label htmlFor="password">password</label>
        <br />
        <input
          type="text"
          value={password}
          name="password"
          onChange={e => setPassword(e.target.value)}
        />
        <br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};
export default Form1;
