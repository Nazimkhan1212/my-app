import React from "react";

const Render1 = () => {
  const [counter, setCounter] = React.useState(0);
  const [show, setShow] = React.useState(false);

  const movies = [
    { id: "mov1", value: "The Last Samurai" },
    { id: "mov2", value: "Van Helsing" },
    { id: "mov3", value: "Braveheart" },
    { id: "mov4", value: "A Few Good Men" },
    { id: "mov4", value: "Star Wars: Episode III - Revenge of the Sith" },
  ];
  return (
    <div>
      <p>{counter}</p>
      <button onClick={() => setCounter(counter + 1)}>incremen</button>
      <button onClick={() => setCounter(counter - 1)}>decrement </button>
      <br />
      <br />
      <br />

      <button onClick={() => setShow(!show)}>{show ? "hide" : "show"}</button>
      <ul>
        {show
          ? movies.map((movie, i) => <li key={i}> {movie.value}</li>)
          : null}
      </ul>
    </div>
  );
};

export default Render1;
