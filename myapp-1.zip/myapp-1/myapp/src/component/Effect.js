import { useState, useEffect } from 'react';
import axios from 'axios';

const Effect = () => {
  const [data, setData] = useState([]);
  const [count, setCount] = useState(0);

  useEffect(() => {
    const getData = async () => {
      const response = await axios.get('https://pokeapi.co/api/v2/pokemon');
      setData(response.data.results);
    };
    getData();
  }, []);  

  return (
    <div>
      <h1>Count - {count}</h1>
      <button onClick={() => setCount(count + 1)}>Increase count</button> 
      {data.map((item,i) => (
        <p key={i}>{item.name}</p>
      ))}
    </div>
  );
};

export default Effect;
