import Header from './component/Header';
import Footer from './component/Footer';
// import Form from './component/Form';
// import Render from './component/Render';
// import Todo from './component/Todo';
// import Effect from './component/Effect';
// import Form1 from './component/Form1';
// import Render1 from './component/Render1';
import Effect1 from './component/Effect1';

const App = () => {
  return (
    <>
      <Header />
      <h3>I am from the app component</h3>
      <hr />
      {/* <Form1/> */}
      {/* <Form /> */}
      {/* <Render /> */}
      {/* <Render1/> */}
      {/* <Todo /> */}
      <hr />
      <Effect1/>
      <Footer />
      {/* <Effect /> */}
    </>
  );
};

export default App;
