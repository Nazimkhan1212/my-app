// CommonJS
const http = require('http');

const server = http.createServer((req, res) => {
  // console.log(req.url, req.method, req.headers);
  // process.exit();

  console.log(req.url);

  if (req.url === '/') {
    res.setHeader('Content-Type', 'text/html');
    res.write(`
    <html>
      <head>
        <title>My Node App</title>
        <body>
          <h1>My Application</h1>
        </body>
      </head>
    </html>
  `);
    res.end();
  } else if (req.url === '/about') {
    res.setHeader('Content-Type', 'text/html');
    res.write(`
    <html>
      <head>
        <title>My Node App</title>
        <body>
          <h1>My About Page</h1>
        </body>
      </head>
    </html>
  `);
    res.end();
  } else {
    res.setHeader('Content-Type', 'text/html');
    res.write(`
    <html>
      <head>
        <title>My Node App</title>
        <body>
          <h1>404 NOT FOUND</h1>
        </body>
      </head>
    </html>
  `);
    res.end();
  }
});

server.listen(5000);
